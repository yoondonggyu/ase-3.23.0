raise ImportError(
    'The ase.ga.bulk_utilities module has been deprecated. '
    'The same functionality is now provided by the '
    'ase.ga.utilities module.')
